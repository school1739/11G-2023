"""
Program for calculating roots of a quadratic equation
"""

a = int(input('Введите значение A: '))
b = int(input('Введите значение B: '))
c = int(input('Введите значение C: '))

if a ==1:
  if b == 1:
    print('Уравнение вида x² + ','x + ', c, ' = 0')
  elif b == -1:
    print('Уравнение вида x² + ','-x + ', c, ' = 0')
  else:
    print('Уравнение вида x² + ', b, 'x + ', c, ' = 0')
    print('Уравнение вида x² + ', b, 'x + ', c, ' = 0')
elif a == -1:
  if b == 1:
    print('Уравнение вида x² + ','x + ', c, ' = 0')
  elif b == -1:
    print('Уравнение вида x² + ','-x + ', c, ' = 0')
  else:
    print('Уравнение вида x² + ', b, 'x + ', c, ' = 0')
    print('Уравнение вида x² + ', b, 'x + ', c, ' = 0')
    print('Уравнение вида -x² + ', b, 'x + ', c, ' = 0')
else:
  if b == 1:
    print('Уравнение вида x² + ','x + ', c, ' = 0')
  elif b == -1:
    print('Уравнение вида x² + ','-x + ', c, ' = 0')
  else:
    print('Уравнение вида x² + ', b, 'x + ', c, ' = 0')
    print('Уравнение вида x² + ', b, 'x + ', c, ' = 0')
    print('Уравнение вида ',a,'x² + ', b,'x + ', c, ' = 0')


def calculate_discripminant(a, b, c):
  """Calculation of discripminant

  This funcsion is calculating a Discripminant using the quartic equation arguments.

  Arguments:
     a -- coefficient of x²
     b -- coefficient of x
     c -- constant

  Returns:
     Discriminant (real)
  """
  return b**2 - 4 * a * c

"""
Checking the existence (and number) and calculating roots 
based on the discriminant
"""
def calculation_roots(d, a, b):
  """The Great calculation of roots

  As you already know, this function is calculating roots of a quadratic equation,
  in the name of ALL Godness, is calculating roots of a quadratic equation.

  Args:
      d (int): discriminant
      a (int): first coefficient
      b (int): second coefficient
  Returns:
      None (because it prints)
  """

if d > 0: 
  x1 = (-b + d ** 0.5)/(2 * a)
  x2 = (-b - d ** 0.5)/(2 * a)
  print('x₁=',x1)
  print('x₂=',x2)
elif d == 0:
  x = -b/ (2 * a)
  print('x=', x)
else:
  print("Нет кореней")

print(calculate_roots.__doc__)


"""
Enter the coefficients of the equation: a, b, c
Equation coefficients -- int
"""
a = int(input("Введите a: "))
b = int(input("Введите b: "))
c = int(input("Введите c: "))

# Calculation of discriminant
calculate_discriminant(a, b, c)

calculate_roots(a, b, c)